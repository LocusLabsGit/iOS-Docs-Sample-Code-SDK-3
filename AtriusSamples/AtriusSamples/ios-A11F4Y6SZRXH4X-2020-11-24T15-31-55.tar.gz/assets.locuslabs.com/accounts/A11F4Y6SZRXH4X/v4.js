locuslabs.elvis2.loaded("venueList/v4",{
    "gru": {
        "airportCode": "GRU",
        "assetVersion": "2020-07-08T23:11:19",
        "id": "gru",
        "locale": "en",
        "name": "São Paulo–Guarulhos International Airport"
    },
    "grupo": {
        "airportCode": "GRU",
        "assetVersion": "2020-07-08T23:11:20",
        "id": "grupo",
        "locale": "pt",
        "name": "Aeroporto Internacional de São Paulo"
    },
    "grusp": {
        "airportCode": "GRU",
        "assetVersion": "2020-07-08T23:11:20",
        "id": "grusp",
        "locale": "es",
        "name": "Aeropuerto Internacional de Sao Paulo"
    },
    "lax": {
        "airportCode": "LAX",
        "assetVersion": "2020-11-24T15:31:55",
        "beaconRegions": [
            {
                "uuid": "B9EF4675-D791-43CC-9CAD-A522DE95005A"
            },
            {
                "majorId": 1600,
                "uuid": "B9EF4675-D791-43CC-9CAD-A522DE95005A"
            },
            {
                "majorId": 2100,
                "uuid": "B9EF4675-D791-43CC-9CAD-A522DE95005A"
            }
        ],
        "id": "lax",
        "locale": "en",
        "name": "Los Angeles International Airport",
        "positioningSupported": [
            "CoreLocation"
        ]
    },
    "sea": {
        "airportCode": "SEA",
        "assetVersion": "2020-11-24T22:21:46",
        "beaconRegions": [
            {
                "uuid": "F314E533-588D-40EE-A52C-FADACB2022AB"
            },
            {
                "uuid": "7D13A6B3-AE93-458A-B3EC-51389CD9F08A"
            }
        ],
        "id": "sea",
        "locale": "en",
        "name": "Seattle-Tacoma International Airport",
        "positioningSupported": [
            "Beacons"
        ]
    },
    "stn": {
        "airportCode": "stn",
        "assetVersion": "2020-10-30T17:18:36",
        "id": "stn",
        "locale": "en",
        "name": "London Stansted Airport"
    }
});